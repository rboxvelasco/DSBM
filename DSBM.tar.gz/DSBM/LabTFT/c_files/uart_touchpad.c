#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <pthread.h>
#include <errno.h>
#include "lib.h"
#include "colors.h"

#define SERIAL_PORT "/dev/ttyAMA0"
#define BAUD_RATE   B9600

// --- Variables globals ----------------------------------------
static int  fd          = -1;
static volatile int running = 1;


// -------------------------------------------------------------

// --- Calibració touchpad → pantalla --------------------------
//
//   screen_x = 0.382295 * touch_x + 0.011948 * touch_y - 64.2113
//   screen_y = 0.014370 * touch_x + 0.569150 * touch_y - 92.7876
//
// Coeficients escalats x65536 per evitar floats (apta per MCU/embedded)
//
#define CAL_A   25055    /*  0.382295 * 65536 */
#define CAL_B     783    /*  0.011948 * 65536 */
#define CAL_C  -4208630  /* -64.2113  * 65536 */

#define CAL_D     942    /*  0.014370 * 65536 */
#define CAL_E   37299    /*  0.569150 * 65536 */
#define CAL_F  -6079841  /* -92.7876  * 65536 */

static inline void touch_to_screen(uint16_t touch_x, uint16_t touch_y,
                                    int *screen_x,    int *screen_y)
{
    int32_t sx = (CAL_A * (int32_t)touch_x + CAL_B * (int32_t)touch_y + CAL_C) >> 16;
    int32_t sy = (CAL_D * (int32_t)touch_x + CAL_E * (int32_t)touch_y + CAL_F) >> 16;

    // Clamp al àrea de pantalla
    if (sx < 0)        sx = 0;
    if (sx > Size_X) sx = Size_X;
    if (sy < 0)        sy = 0;
    if (sy > Size_Y) sy = Size_Y;

    *screen_x = (int)sx;
    *screen_y = (int)sy;
}


int open_serial(const char *port) {
    int fd = open(port, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) {
        fprintf(stderr, "[ERROR] No s'ha pogut obrir %s: %s\n", port, strerror(errno));
        return -1;
    }

    struct termios tty;
    memset(&tty, 0, sizeof tty);

    if (tcgetattr(fd, &tty) != 0) {
        fprintf(stderr, "[ERROR] tcgetattr: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    // Baud rate
    cfsetospeed(&tty, BAUD_RATE);
    cfsetispeed(&tty, BAUD_RATE);

    // 8N1: 8 bits de dades, sense paritat, 1 stop bit
    tty.c_cflag &= ~PARENB;         // Sense paritat
    tty.c_cflag &= ~CSTOPB;         // 1 stop bit
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |=  CS8;            // 8 bits de dades

    // Sense control de flux hardware
    tty.c_cflag &= ~CRTSCTS;

    // Habilita recepcio, ignora modem controls
    tty.c_cflag |= CREAD | CLOCAL;

    // Mode raw (sense processament especial)
    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);        // Sense control de flux software
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK |
                     ISTRIP | INLCR  | IGNCR | ICRNL);
    tty.c_oflag &= ~OPOST;                          // Sense processament de sortida

    // Timeout de lectura: 1 segon
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 10;   // 10 * 100ms = 1 segon

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        fprintf(stderr, "[ERROR] tcsetattr: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    printf("[OK] Port obert: %s @ 9600 baud 8N1\n", port);
    return fd;
}


// --- Thread de recepcio ---------------------------------------


void *rx_thread(void *arg) {
    (void)arg;
    char packet[4];
    int received = 0;

    while (running) {
        char byte;
        int n = read(fd, &byte, 1);
        if (n > 0) {
            packet[received++] = byte;
            if (received == 4) {
                uint16_t x = (uint16_t)(packet[0] | (packet[1] << 8));
                uint16_t y = (uint16_t)(packet[2] | (packet[3] << 8));
                //uint16_t y = 0:
                //printf("[RX] X=%u  Y=%u\n", x, y);

int sx, sy;
touch_to_screen(x, y, &sx, &sy);
printf("[RX] touch=(%u, %u)  ->  screen=(%d, %d)\n", x, y, sx, sy);
draw_pixel(sx-1, sy-1, RED);
draw_pixel(sx, sy-1, RED);
draw_pixel(sx+1, sy-1, RED);

draw_pixel(sx-1, sy, RED);
draw_pixel(sx, sy, RED);
draw_pixel(sx+1, sy, RED);

draw_pixel(sx-1, sy+1, RED);
draw_pixel(sx, sy+1, RED);
draw_pixel(sx+1, sy+1, RED);

                fflush(stdout);
                received = 0;
            }
        } else if (n < 0 && errno != EAGAIN) {
            fprintf(stderr, "[ERROR RX] %s\n", strerror(errno));
            running = 0;
        }
    }
    return NULL;
}


/*
void *rx_thread(void *arg) {
    (void)arg;
    char buf[64];

    while (running) {
        int n = read(fd, buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            printf("[RX] ");
            for (int i = 0; i < n; i++) {
                unsigned char c = (unsigned char)buf[i];
                    printf("%u", c);   // Caracter imprimible
            }
            printf("\n");
            fflush(stdout);
        } else if (n < 0 && errno != EAGAIN) {
            fprintf(stderr, "[ERROR RX] %s\n", strerror(errno));
            running = 0;
        }
    }
    return NULL;
}
*/

// --- Bucle de transmissio -------------------------------------
void tx_loop() {
    char input[256];

    printf("\nEscriu text i prem Enter per enviar al PIC.\n");
    printf("Comandes especials:\n");
    printf("  :quit  -> sortir\n");
    printf("  :ping  -> envia '?'\n\n");

    while (running) {
        printf("> ");
        fflush(stdout);

        if (!fgets(input, sizeof(input), stdin)) {
            running = 0;
            break;
        }

        // Elimina el newline final
        input[strcspn(input, "\n")] = '\0';

        if (strcmp(input, ":quit") == 0) {
            running = 0;
            break;
        }

        char payload[258];
        int  len;

        if (strcmp(input, ":ping") == 0) {
            strcpy(payload, "?");
            len = 1;
        } else {
            len = snprintf(payload, sizeof(payload), "%s\r\n", input);
        }

        int written = write(fd, payload, 1);
        if (written < 0)
            fprintf(stderr, "[ERROR TX] %s\n", strerror(errno));
        else
            printf("[TX] %.*s\n", len, payload);
    }
}


int main() {
    init();
    clear_screen(GREEN);

    fd = open_serial(SERIAL_PORT);
    if (fd < 0) {
        fprintf(stderr, "Comprova:\n");
        fprintf(stderr, "  1. sudo raspi-config -> Interface Options -> Serial\n");
        fprintf(stderr, "  2. sudo usermod -aG dialout $USER  (i re-login)\n");
        return EXIT_FAILURE;
    }

    // Inicia el thread de recepcio
    pthread_t rx;
    if (pthread_create(&rx, NULL, rx_thread, NULL) != 0) {
        fprintf(stderr, "[ERROR] No s'ha pogut crear el thread RX\n");
        close(fd);
        return EXIT_FAILURE;
    }

    tx_loop();

    // Neteja
    running = 0;
    pthread_join(rx, NULL);
    close(fd);
    printf("[OK] Port tancat. Fins aviat!\n");
    return EXIT_SUCCESS;
}
